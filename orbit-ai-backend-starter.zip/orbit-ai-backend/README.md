# Orbit AI Node.js backend starter

This is a starter backend for the Orbit AI GitHub Pages frontend. It provides:
- `GET /health` health check
- `POST /api/chat` demo endpoint returning `{ "reply": "..." }`
- Basic JSON size limit, Helmet security headers, and configurable CORS

## Important limitations
This starter does **not** connect a real AI model, WhatsApp, Instagram, Facebook, or phone calls yet. The chat endpoint returns a demo response. Real platform integrations require official API credentials, webhook verification, permissions, and additional code.

## Deploy on Render (Android phone)
1. Upload these files to the **root** of your GitHub repository `RAJkumar123887/assistant-`, alongside (not replacing) your existing `index.html`.
2. In Render, create **New → Web Service** and select that repository.
3. Choose **Node** as the runtime/language, not Docker.
4. Set **Build Command** to `npm install`.
5. Set **Start Command** to `npm start`.
6. Choose the Free instance if available and click Deploy.
7. In Render's service dashboard, open the URL ending in `onrender.com` and add `/health`. It should return JSON with `"ok": true`.
8. In Render → Environment, add `FRONTEND_ORIGIN` with the exact published GitHub Pages origin, e.g. `https://USERNAME.github.io` (no path or trailing slash). For a project site, the browser Origin is still usually `https://USERNAME.github.io`.
9. Save and redeploy if prompted.

## Connect the frontend
In Orbit AI → Settings, enter the Render base URL (e.g. `https://your-service.onrender.com`) and chat path `/api/chat`, then save for the current page session and test in AI Assistant.

## Secrets
Never put API keys, Meta access tokens, or `.env` values in GitHub files or browser JavaScript. Add secrets only in Render's Environment settings.

## Free-plan note
Free services may sleep after inactivity, causing a delay on the first request. External API usage can cost money.
