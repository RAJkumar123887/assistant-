const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "";

app.use(helmet());
app.use(express.json({ limit: "20kb" }));

// Allow only your GitHub Pages website when FRONTEND_ORIGIN is configured.
// For local testing, requests without an Origin header are allowed.
app.use(cors({
  origin(origin, callback) {
    if (!origin || !FRONTEND_ORIGIN || origin === FRONTEND_ORIGIN) {
      return callback(null, true);
    }
    return callback(new Error("Origin not allowed by CORS"));
  }
}));

app.get("/", (_req, res) => {
  res.json({
    name: "Orbit AI Backend",
    status: "running",
    note: "Starter backend only. Live AI and social integrations are not configured."
  });
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "orbit-ai-backend" });
});

// Compatible with the Orbit AI frontend's expected POST /api/chat shape.
// This is a safe demo response until you add an AI provider and server-side key.
app.post("/api/chat", (req, res) => {
  const message = typeof req.body?.message === "string"
    ? req.body.message.trim()
    : "";
  const language = typeof req.body?.language === "string"
    ? req.body.language.slice(0, 12)
    : "en";

  if (!message) {
    return res.status(400).json({ error: "Please provide a message." });
  }
  if (message.length > 4000) {
    return res.status(413).json({ error: "Message is too long (maximum 4000 characters)." });
  }

  let reply;
  if (language.toLowerCase().startsWith("te")) {
    reply = "మీ సందేశం అందింది. ఇది Orbit AI డెమో బ్యాకెండ్ మాత్రమే; నిజమైన AI సమాధానాల కోసం సర్వర్‌లో AI APIని సురక్షితంగా కాన్ఫిగర్ చేయాలి.";
  } else {
    reply = "Your message reached the Orbit AI backend. This is a demo response; configure an AI provider securely on the server to enable real AI answers.";
  }

  return res.json({ reply, demo: true });
});

// Placeholder only: real platform webhook verification and processing must be added
// before registering this URL with Meta or a phone provider.
app.get("/webhooks/meta", (_req, res) => {
  res.status(501).json({ error: "Meta webhook is not configured yet." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Orbit AI backend listening on port ${PORT}`);
});
